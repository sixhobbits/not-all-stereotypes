

     #######################################################################
     ##  This script does the following:
     ##
     ##  1. reads Expt and Filler stim files 
     ##     NOTE: the files should be well prepared for import, including:
     ##     - no "hard returns" inside cells
     ##     - saved as Windows Formatted Text (.txt)
     ##  2. writes CW number for each item to file:  CW.num.txt
     ##  3. replaces '\x92' with apostrophe
     ##  4. writes Ibex format to file:  stims.in.Ibex.format.txt
     ##  5. prints Ibex format to console
     ##      -->  cut and paste into ExptMethods_example.js
     #######################################################################


# set paths
StimsDir = '~/Documents/WORK IN PROGRESS/Saarland/2016 Summer/ExptMethods/CourseExpt/Stims' 
DataDir = '~/Documents/WORK IN PROGRESS/Saarland/2016 Summer/ExptMethods/CourseExpt/Analysis/Data'

# set working directory
setwd(StimsDir)

# read stims
d1 <- read.table('pS.pK.txt', sep = "\t", quote = '',  
                 header = TRUE, strip.white = TRUE)  
d2 <- read.table('pS.mK.txt', sep = "\t", quote = '',
                 header = TRUE, strip.white = TRUE)
d3 <- read.table('mS.pK.txt', sep = "\t", quote = '',
                 header = TRUE, strip.white = TRUE)
d4 <- read.table('mS.mK.txt', sep = "\t", quote = '',
                 header = TRUE, strip.white = TRUE)
d5 <- read.table('fillers.txt', sep = "\t", quote = '',
                 header = TRUE, strip.white = TRUE)

# merge into single df
d0 <- rbind(d1,d2,d3,d4,d5)
names(d0) <- c("Cond","Item","Context","Statement","CW","CompQ","Qnum","CorrectAns")

# create tabe of CW number for each item
cw <- unique(d0[ , c("Item","Statement","CW")])

# write cw to Data directory
setwd(DataDir)
write.table(cw, 'CW.number.txt', sep="\t", row.names=F, quote=F)

# replace all '\x92' with apostrophe
d0 <- data.frame(lapply(d0, function(x) {
     gsub("\x92", "'", x)
}))

# convert all columns to character class
d0 <- data.frame(lapply(d0, as.character), stringsAsFactors=FALSE)

#-------------------------------------------------------------------------------
# items should look like this once formatted for Ibex:

# [["pS.pK", 2],
#  "Message", {html: ["div",
#                     ["p", "Maria is a 20-year-old American girl from Las 
#                      Vegas. She studies game theory at the University of 
#                      Melbourne."],
#                     ["p", "Press any key to continue to see this person's 
#                      statement."]
#                     ]},
#  "DashedSentence", {s: "Every Friday night, I like to go to the casino to 
#       play poker."},
#  "Question", {q: "Based on the profile:  Does Maria study philosophy of 
#       religion?",
#       hasCorrect: 1,
#       timeOut: 4500
#  }],

# Note: Answers to questions are coded as Yes=0, No=1 
#-------------------------------------------------------------------------------

# write Ibex formated stims to console
for (i in 1:nrow(d0))
     {
     cat('[["', d0$Cond[i], '", ', d0$Item[i], '],
         "Message", {html: ["div", 
         ["p", "', d0$Context[i], '"], 
         ["p", "Press any key to continue to see this persons statement."] 
         ]}, 
         "DashedSentence", {s: "', d0$Statement[i], '"}, 
         "Question", {q: "Based on the profile: ', d0$CompQ[i], '", 
         hasCorrect: ', d0$CorrectAns[i], ',
         timeOut: 4500
         }],',
         '\n', sep='')
} 
#     ***** NEED TO REMOVE FINAL COMMA AFTER PASTING INTO IBEX *****

# write Ibex formated stims to file
# create df for reformatted data
out <- data.frame(matrix(nrow=0,ncol=1)) 
thisRow <- 1   
for (i in 1:nrow(d0))
{
     out[i, 1] <-
          paste(
               '[["',
               d0$Cond[i],
               '", ',
               d0$Item[i],
               '], "Message", {html: ["div", ["p", "',
               d0$Context[i],
               '"], ["p", "Press any key to continue to see this persons statement."]]}, "DashedSentence", {s: "',
               d0$Statement[i],
               '"}, "Question", {q: "Based on the profile: ',
               d0$CompQ[i],
               '", hasCorrect: ',
               d0$CorrectAns[i],
               ', timeOut: 4500 }],',
               sep = ''
          )
     thisRow <- thisRow + 1
} 
out[i, 1] <- "***** NEED TO REMOVE FINAL COMMA AFTER PASTING INTO IBEX *****"
setwd(StimsDir)
write.table(out, 'stims.in.Ibex.format.txt', sep="\t", row.names=F, quote=F) 



